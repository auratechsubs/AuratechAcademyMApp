class Assets {
  static const _imagesBase = "assets/images/";
  static const Splacescreenseconflogo = "${_imagesBase}splashlogosecond.png";
}
