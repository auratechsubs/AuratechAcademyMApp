class GlobalVariables {
  static bool isLogin = false;
}